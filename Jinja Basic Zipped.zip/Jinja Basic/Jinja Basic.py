from flask import Flask
from flask import render_template

import random
import datetime
app = Flask(__name__)

@app.route('/')
def home():
    n = random.randint(0, 20)
    cy = datetime.datetime.now().year
    return render_template("index.html", num = n, year = cy)

if __name__ == "__main__":
    app.run(debug = True)