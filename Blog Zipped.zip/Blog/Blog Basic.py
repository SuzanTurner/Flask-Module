from flask import Flask
from flask import render_template

import requests

app = Flask(__name__)

@app.route('/')
def home():
    URL = "https://api.npoint.io/42fd5ab335f1e33b9ad7"
    resp = requests.get(URL)
    blog = resp.json()
    return render_template('index.html', b = blog)

if __name__ == "__main__":
    app.run(debug = True)



