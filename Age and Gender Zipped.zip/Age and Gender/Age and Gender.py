from flask import Flask
from flask import render_template

import requests

app = Flask(__name__)

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/<name>')
def guess(name):
    GEND = f"https://api.genderize.io?name={name}"
    resp = requests.get(GEND)
    resp.raise_for_status()
    print(resp.raise_for_status())
    data = resp.json()
    c = data["count"]
    g = data["gender"]
    AGE = f"https://api.agify.io?name={name}"
    response = requests.get(AGE)
    response.raise_for_status
    d = response.json()
    a = d["age"]
    return render_template("guess.html", n = name, count = c, gender = g, age = a)


if __name__ == "__main__":
    app.run(debug = True)

    