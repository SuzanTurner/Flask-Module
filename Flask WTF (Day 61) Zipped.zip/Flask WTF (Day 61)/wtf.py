from flask import Flask, render_template, request
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField
from wtforms.validators import InputRequired, ValidationError

from flask_bootstrap import Bootstrap5

app = Flask(__name__)
Bootstrap5(app)
app.config['SECRET_KEY'] = "DontTellAnyone"

class loginform(FlaskForm):
    username = StringField('username', validators = [InputRequired()])
    password = PasswordField('password', validators = [InputRequired()])

    def validate_username(form, username):
        if len(username.data) > 50:
            raise ValidationError('Name must be less than 50 characters')
        
    def validate_password(form, password):
        if len(password.data) < 8:
            raise ValidationError('Password must be at least 8 cahracters')
       
@app.route('/', methods = ["GET", "POST"])
def home():
    form = loginform()
    if form.validate_on_submit():
        if form.username.data == "yadh" and form.password.data == "adipadiii":
            return "Success!!"
        else:
            return "Access Denied"

    return render_template('login.html', form = form)

if __name__ == "__main__":
    app.run(debug = True)